export default function Results(props) {
    const num = props.currentAnswersNum
    return <div>
        <h2>Congratulation!</h2>
        <h3>You'r grade is: {Math.round((100 / 3) * num)}%</h3>
        <h3>You answer {num} out of 3</h3>
        <button onClick={props.reset}>Start Over</button>
    </div>
}