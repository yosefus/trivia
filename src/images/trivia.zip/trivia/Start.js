export default function Start({ click }) {
    return <button onClick={click}>Start</button>
}
