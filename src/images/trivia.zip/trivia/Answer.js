export default function Answer(props) {
    return <div>
        <label>
            <input
                required
                type='radio'
                name={props.name}
                value={props.index}
            />
            {props.a}</label>
    </div>
}