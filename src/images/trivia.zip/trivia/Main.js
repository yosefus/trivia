import Form from "./Form";
import Test from "./Test";

export default function Main() {
    return <main>
        <Form />
        <Test />
    </main>
}