import { useEffect, useState } from "react"

const START_VALUE = (10 * 1000)
export default function Timer(props) {
    const [time, setTime] = useState(START_VALUE)

    useEffect(function () {
        const end = Date.now() + START_VALUE
        const interval = setInterval(() => {
            const x = end - Date.now()
            if (x < 0) props.onEnd()
            setTime(x)
            return () => clearInterval(interval)
        }, 1000)
    }, [])

    return <div>{Math.round(time / 1000)}</div>
}