import { useEffect, useState } from "react"
import QuestionItem from "./QuestionItem"
import Timer from "./Timer"

export default function Questions(props) {
    const [list, setList] = useState([])

    function startTest() {
        const qs = JSON.parse(localStorage.q)
        let rqs = []

        for (let i = 0; i < 3; i++) {
            const
                r = Math.floor(Math.random() * qs.length),
                rq = qs.splice(r, 1)
            rqs = [...rqs, ...rq]
        }
        setList(rqs)
    }

    useEffect(startTest, [])

    function handleSubmit(e) {
        e.preventDefault()
        const
            form = e.target,
            values = Object.values(form),
            currentAnswersNum = values
                .filter(v => v.checked)
                .map(v => ({ value: v.value, name: v.name }))
                .filter(v => {
                    const res = list.find(l => l.name == v.name)
                    return res.correctAnswer == v.value
                }).length
        props.onEnd(currentAnswersNum)
    }

    return <form onSubmit={handleSubmit}>
        <Timer onEnd={() => props.onEnd(0)} />
        {list.map(q => <QuestionItem key={q.name} q={q} />)}
        <hr />
        <input type='submit' value='End test' />
    </form>
}