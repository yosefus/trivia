import Answer from "./Answer";

export default function QuestionItem({ q }) {
    return <div>
        <h3>{q.name}</h3>
        <div>{
            q.answers.map((a, i) => <Answer
                a={a}
                key={a}
                name={q.name}
                index={i}
            />)
        }</div>
    </div>
}