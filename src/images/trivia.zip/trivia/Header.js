export default function Header() {
    return <h1>Trivia</h1>
}