export default function Form() {

    function createAnswers() {
        const a = []
        for (let index = 0; index < 4; index++) {
            a.push(<label key={index}>
                <input name={`answer ${index}`} placeholder={`answer ${index + 1}`} required />
                <input name='answerIsCorrect' value={index} type='radio' required />
            </label>)
        }
        return a
    }

    function handleSubmit(e) {
        e.preventDefault()
        const obj = { answers: [] }
        const
            form = e.target,
            values = Object
                .values(form)
                .filter(v => (v.name && (v.type == 'radio' ? v.checked : true)))
                .map(v => ({ name: v.name, value: v.value, checked: v.checked }))
        values.forEach(v => {
            const [a, b] = v.name.split(' ')
            if (a === 'answer') obj.answers[b] = v.value
            else if (v.name == 'answerIsCorrect')
                obj.correctAnswer = v.value
            else obj[v.name] = v.value
        })
        const q = JSON.parse(localStorage.q)
        q.push(obj)
        localStorage.q = JSON.stringify(q)

        form.reset()
    }

    return <div className="add">
        <h3>Add Question</h3>
        <form className="add" onSubmit={handleSubmit}>
            <input name='name' placeholder="question" required />
            <br />
            <br />
            {createAnswers()}
            <br />
            <br />
            <input type='submit' value='Add' />
        </form>
    </div>
}