import { useState } from "react"
import Questions from "./Questions"
import Results from "./Results"
import Start from "./Start"

export default function Test() {

    const
        [mode, setMode] = useState('s'),// s | q | num
        restart = () => setMode('q')

    return <div className="test">
        {
            mode === 's' ? <Start click={restart} /> :
                mode === 'q' ? <Questions onEnd={setMode} /> :
                    <Results
                        reset={restart}
                        currentAnswersNum={mode}
                    />
        }
    </div>
}


