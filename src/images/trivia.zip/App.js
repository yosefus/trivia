import './App.css'
import Header from './trivia/Header'
import Main from './trivia/Main'

export default function App() {
    return <div>
        <Header />
        <Main />
    </div>
}